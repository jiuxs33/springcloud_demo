package com.feign.service.model.impl;

import org.springframework.stereotype.Component;

import com.feign.service.model.SchedualServiceHi;

@Component
public class SchedualServiceHiHystric implements SchedualServiceHi {

	@Override
	public String sayHiFromClientOne(String name) {
		// TODO Auto-generated method stub
		return "sorry "+name;
	}

}
